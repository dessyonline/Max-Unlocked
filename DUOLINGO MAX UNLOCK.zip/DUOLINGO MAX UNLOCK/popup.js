/* 
 * Small helper for the extension popup that shows runtime version status.
 * Contributors:
 *  - To change where the latest-version is fetched from, update `VERSION_URL`.
 *  - To change how often the popup refreshes, update the interval passed to setInterval().
 *  - To change the displayed element, update the element id used for `statusEl`.
 *  - If fetch fails in some environments, check CORS/raw file hosting for the VERSION_URL.
 */

// Local-only version display (no GitHub / remote calls).

// Wait until popup DOM is ready (safe place to query elements)
document.addEventListener("DOMContentLoaded", () => {
  // The element in popup.html where we show the version / status text.
  const statusEl = document.getElementById("status");

  // The version field from the extension's manifest (current installed version).
  const currentVersion = chrome.runtime.getManifest().version;

  statusEl.textContent = `Version: v${currentVersion}`;
  statusEl.style.color = "#6bff9b";
});

/*
 * compareVersions(a, b)
 * - a, b are semantic-version-like strings ("1.2.3" etc.)
 * - Splits on '.' and compares numeric components left-to-right.
 * - Missing components are treated as 0 (e.g., "1.2" == "1.2.0").
 * Returns:
 *   1  if a > b
 *   0  if a == b
 *  -1  if a < b
 *
 * Contributors: This is a simple numeric comparator. If you need to support
 * pre-release tags (alpha/beta/rc) or more complex semver rules, consider
 * replacing with a semver library or enhancing the parser.
 */
function compareVersions(a, b) {
  const pa = a.split(".").map(Number);
  const pb = b.split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}
